using Stats.Models.Tests.Internal;
using System;
using Xunit;

namespace Stats.Models.Tests
{
    public class MappingConfigurationValidation
    {
        [Fact]
        public void IsValid()
        {
            //Arrange
            var configuration = AutoMapperModule.CreateMapperConfiguration<MidTerm.Data>();
            //Act/Assert 
            configuration.AssertConfigurationIsValid();
        }
    }
}
