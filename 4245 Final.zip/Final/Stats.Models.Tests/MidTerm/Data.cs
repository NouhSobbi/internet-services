﻿namespace MidTerm
{
    internal class Data
    {
    }
}