﻿using Microsoft.Data.Sqlite;
using midTerm.Data.Entities;
using Microsoft.EntityFrameworkCore;
using midTerm.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace midTerm.Service.Tests.Internal
{
 public abstract class SqLiteContext
    :IDisposable
    {
    private const string InMemoryConnectionString = "DataSource=:memo";
    private readonly SqliteConnection _connection;
    protected readonly MidTermDbContext DBcontext;

    protected SqLiteContext(bool withData = false)
    {
            _connection = new SqliteConnection(InMemoryConnectionString);
            DBcontext = new MidTermDbContext(CreateOptions());
            _connection.Open();
            DBcontext.Database.EnsureCreated();
            if(withData)
            SeedData(DBcontext);
    }
        private DbContextOptions<MidTermDbContext> CreateOptions()
        {
            return new DbContextOptionsBuilder<MidTermDbContext>()
                .EnableDetailedErrors()
                .EnableSensitiveDataLogging()
                .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking)
                .UseSqlite(_connection)
                .Options;
        }

        private void SeedData(MidTermDbContext dBcontext)
        {
            var Option = new List<midTerm.Data.Entities.Option>
            {
                new midTerm.Data.Entities.Option
                {
                    Id=1,
                    Order=1,
                    QuestionId=1,
                    Text = "first option"
                },
                 new midTerm.Data.Entities.Option
                {
                    Id=2,
                    Order=2,
                    QuestionId=2,
                    Text = "second option"
                },
                  new midTerm.Data.Entities.Option
                {
                    Id=3,
                    Order=3,
                    QuestionId=3,
                    Text = "third option"
                }

            };
            var Questions = new List<midTerm.Data.Entities.Question>
            {

                new midTerm.Data.Entities.Question
                {
                    Id=1,
                    Description="this is question number 1",
                    Text="question 1"
                },
                  new midTerm.Data.Entities.Question
                {
                    Id=2,
                    Description="this is question number 2",
                    Text="question 2"
                },
                    new midTerm.Data.Entities.Question
                {
                    Id=3,
                    Description="this is question number 3",
                    Text="question 3"
                }


            };
            DBcontext.AddRange(Option);
            DBcontext.AddRange(Questions);

            DBcontext.SaveChanges();
        }

       

        public void Dispose()
    {
        _connection.Close();
        _connection?.Dispose();
        DBcontext?.Dispose();
    }
}
}
