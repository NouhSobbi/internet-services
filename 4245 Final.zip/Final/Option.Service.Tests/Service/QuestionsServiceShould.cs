﻿using midTerm.Service.Tests.Internal;
using System;
using Xunit;

namespace Questions.Service.Tests
{
    public class QuestionsServiceShould
     : SqLiteContext
    {
        public QuestionsServiceShould()
            : base(true)
        {

        }

        [Fact]
        public void GetQuestionsById()
        {

        }
    }
}
