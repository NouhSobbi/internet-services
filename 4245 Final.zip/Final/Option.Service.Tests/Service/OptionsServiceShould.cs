using midTerm.Service.Tests.Internal;
using System;
using Xunit;

namespace Option.Service.Tests
{
    public class OptionsServiceShould
     :SqLiteContext
    {
        public OptionsServiceShould()
            :base(true)
        { 
        
        }

        [Fact]
        public void GetOptionById()
        {

        }
    }
}
