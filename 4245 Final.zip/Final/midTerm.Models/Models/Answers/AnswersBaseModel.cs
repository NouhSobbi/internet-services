﻿namespace midTerm.Models.Models.Answers
{
    public class AnswersBaseModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int OptionId { get; set; }
    }
}