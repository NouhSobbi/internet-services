﻿namespace midTerm.Infrastructure
{
    public class ConnectionStrings
    {
        public string Default { get; set; }
    }
}
