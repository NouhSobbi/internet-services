﻿using System;

namespace Application.Infraestructure
{
    public class Class1
    {
    }
}
