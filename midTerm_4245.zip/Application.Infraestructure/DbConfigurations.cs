﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Query;
using Microsoft.EntityFrameworkCore.Query.Internal;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using midTerm.Data.Entities;

namespace Application.Infraestructure
{
    public class AnswerConfiguration : IEntityTypeConfiguration<Answers>
    {
        public void Configure(EntityTypeBuilder<Answers> builder)
        {
            builder.ToTable("Answers", "dbo");
            builder.HasKey(x => x.Id).HasName("PK_Answers");//.IsClustered();

            builder.Property(x => x.Id).HasColumnName(@"Id").HasColumnType("int").IsRequired().ValueGeneratedOnAdd();//.UseIdentityColumn();
            builder.Property(x => x.UserId).HasColumnName(@"UserId").HasColumnType("int").IsRequired();
            builder.Property(x => x.OptionId).HasColumnName(@"OptionId").HasColumnType("int").IsRequired();

            // Foreign keys
            builder.HasOne(a => a.Option).WithMany(b => b.Answers).HasForeignKey(c => c.OptionId).OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_Answers_Option");
            builder.HasOne(a => a.SurveyUser).WithMany(b => b.Answers).HasForeignKey(c => c.UserId).OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_Answers_SurveyUser");
        }
    }

    // Option
    public class OptionConfiguration : IEntityTypeConfiguration<Option>
    {
        public void Configure(EntityTypeBuilder<Option> builder)
        {
            builder.ToTable("Option", "dbo");
            builder.HasKey(x => x.Id);
            builder.Property(x=> x.Id).ValueGeneratedOnAdd();

            builder.Property(x => x.Id).HasColumnName(@"Id").HasColumnType("int").IsRequired().ValueGeneratedOnAdd();//.UseIdentityColumn();
            builder.Property(x => x.Text).HasColumnName(@"Text").HasColumnType("varchar(1000)").IsRequired().IsUnicode(false).HasMaxLength(1000);
            builder.Property(x => x.Order).HasColumnName(@"Order").HasColumnType("int").IsRequired(false);
            builder.Property(x => x.QuestionId).HasColumnName(@"QuestionId").HasColumnType("int").IsRequired();

            // Foreign keys
            builder.HasOne(a => a.Question).WithMany(b => b.Options).HasForeignKey(c => c.QuestionId).OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_Option_Question1");
        }
    }

    // Question
    public class QuestionConfiguration : IEntityTypeConfiguration<Question>
    {
        public void Configure(EntityTypeBuilder<Question> builder)
        {
            builder.ToTable("Question", "dbo");
            builder.HasKey(x => x.Id);//.HasName("PK_Question").IsClustered();
            builder.Property(x => x.Id).ValueGeneratedOnAdd();
            builder.Property(x => x.Id).HasColumnName(@"Id").HasColumnType("int").IsRequired().ValueGeneratedOnAdd();//.UseIdentityColumn();
            builder.Property(x => x.Text).HasColumnName(@"Text").HasColumnType("varchar(100)").IsRequired().IsUnicode(false).HasMaxLength(100);
            builder.Property(x => x.Description).HasColumnName(@"Description").HasColumnType("varchar(1000)").IsRequired().IsUnicode(false).HasMaxLength(1000);
        }
    }

    // SurveyUser
    public class SurveyUserConfiguration : IEntityTypeConfiguration<SurveyUser>
    {
        public void Configure(EntityTypeBuilder<SurveyUser> builder)
        {
            builder.ToTable("SurveyUser", "dbo");
            builder.HasKey(x => x.Id);//.HasName("PK_SurveyUser").IsClustered();
            builder.Property(x => x.Id).ValueGeneratedOnAdd();
            builder.Property(x => x.Id).HasColumnName(@"Id").HasColumnType("int").IsRequired().ValueGeneratedOnAdd();//.UseIdentityColumn();
            builder.Property(x => x.FirstName).HasColumnName(@"FirstName").HasColumnType("varchar(100)").IsRequired().IsUnicode(false).HasMaxLength(100);
            builder.Property(x => x.LastName).HasColumnName(@"LastName").HasColumnType("varchar(100)").IsRequired().IsUnicode(false).HasMaxLength(100);
            builder.Property(x => x.DoB).HasColumnName(@"DoB").HasColumnType("datetime").IsRequired(false);
            builder.Property(x => x.Gender).HasColumnName(@"Gender").HasColumnType("varchar(10)").IsRequired().IsUnicode(false).HasMaxLength(10);
            builder.Property(x => x.Country).HasColumnName(@"Country").HasColumnType("nchar(10)").IsRequired().IsFixedLength().HasMaxLength(10);
        }
    }
}
