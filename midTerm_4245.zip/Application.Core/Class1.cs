﻿using System;

namespace Application.Core
{
    public class Class1
    {
    }
}
