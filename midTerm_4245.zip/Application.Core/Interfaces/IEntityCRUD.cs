﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Application.Core.Interfaces
{
    public interface IEntityCRUD<T> where T : class
    {
        public Task<int> Insert(T t);

        public Task<T> Retrieve(int id);

        public Task<List<T>> RetrieveAll();

        public Task<bool> Update(T t);

        public Task<bool> Delete (int id);



    }
}
