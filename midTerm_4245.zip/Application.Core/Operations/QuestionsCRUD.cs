﻿using Application.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using midTerm.Data.Entities;
using System.Linq;
using System.Threading.Tasks;
using Application.Infraestructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Application.Core.Questions
{
    public class QuestionsCRUD : IEntityCRUD<Question>
    {
        SurveyContext _context;
        public QuestionsCRUD(IConfiguration config)
        {
            var optionsBuilder = new DbContextOptionsBuilder<SurveyContext>();
            optionsBuilder.UseSqlServer(config.GetConnectionString("DefaultConnection"));

            _context = new SurveyContext(optionsBuilder.Options);
        }



        public async Task<bool> Delete(int t)
        {
            var entityToDelete = _context.Option.SingleOrDefault(x => x.Id == t);
            if (entityToDelete != null)
            {
                _context.Option.Remove(entityToDelete);

                var changes = await _context.SaveChangesAsync(new System.Threading.CancellationToken());
                return changes != 0;
            }
            else return false;

        }

        public async Task<int> Insert(Question t)
        {
            _context.Question.Add(t);
            await _context.SaveChangesAsync(new System.Threading.CancellationToken());
            return t.Id;
        }

        public async Task<Question> Retrieve(int id)
        {
            var toRetrieve = _context.Question.SingleOrDefault(x => x.Id == id);
            return toRetrieve;
        }

        public async Task<List<Question>> RetrieveAll()
        {
            return _context.Question.ToList();
        }
        public async Task<bool> Update(Question t)
        {
            var toUpdate = _context.Question.SingleOrDefault(x => x.Id == t.Id);

            toUpdate.Text = t.Text;
            toUpdate.Description = t.Description;

            if (t.Text == t.Description)
                throw new Exception("Question text cannot be the same than question description");

            var result = await _context.SaveChangesAsync(new System.Threading.CancellationToken());
            return result != 0;
        }
    }
}
