﻿using Application.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using midTerm.Data.Entities;
using System.Linq;
using System.Threading.Tasks;
using Application.Infraestructure;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;

namespace Application.Core.Options
{
    public class OptionsCRUD : IEntityCRUD<Option>
    {
        SurveyContext  _context;
        public OptionsCRUD(IConfiguration config)
        {
            var optionsBuilder = new DbContextOptionsBuilder<SurveyContext>();
            optionsBuilder.UseSqlServer(config.GetConnectionString("DefaultConnection"));
            
            _context = new SurveyContext(optionsBuilder.Options);
        }



        public async Task<bool> Delete(int t)
        {
            var entityToDelete = _context.Option.SingleOrDefault(x => x.Id == t);
            if (entityToDelete != null)
            {
                _context.Option.Remove(entityToDelete);

                var changes = await  _context.SaveChangesAsync(new System.Threading.CancellationToken());
                return changes != 0;
            }
            else return false;

        }

        public async Task<int> Insert(Option t)
        {
            _context.Option.Add(t);
            await _context.SaveChangesAsync(new System.Threading.CancellationToken());
            return t.Id;
        }

        public async Task<Option> Retrieve(int id)
        {
            var toRetrieve =  _context.Option.SingleOrDefault(x => x.Id == id);
            return toRetrieve;
        }

        public async Task<List<Option>> RetrieveAll()
        {
            return _context.Option.ToList();
        }

        public async Task<bool> Update(Option t)
        {
            var toUpdate  = _context.Option.SingleOrDefault(x => x.Id == t.Id);

            toUpdate.Order = t.Order;
            toUpdate.Question = t.Question;
            toUpdate.QuestionId = t.QuestionId;
            toUpdate.Text = t.Text;
         
             var result = await _context.SaveChangesAsync(new System.Threading.CancellationToken());
            return result != 0;
        }
    }
}
