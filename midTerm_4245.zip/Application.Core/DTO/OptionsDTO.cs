﻿using midTerm.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.Core.DTO
{
    public class OptionsDTO : Option
    {
    }
}
