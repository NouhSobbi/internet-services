﻿using Application.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Design;

using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Query;
using midTerm.Data.Entities;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Application.Infraestructure
{
  public  class SurveyContext : DbContext
    {

        public SurveyContext()
        {

        }

       public DbSet<Answers> Answers { get; set; }
       public DbSet<Option> Option { get; set; }
       public DbSet<Question> Question { get; set; }
       public DbSet<SurveyUser> SurveyUser { get; set; }


        public DatabaseFacade Facade => this.Database;

     
        public SurveyContext(DbContextOptions options) : base(options)
        {
            // _currentUserService = currentUserService;
            // _dateTime = dateTime;
        }
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            

            var response = await base.SaveChangesAsync(cancellationToken);

            return response;

        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
            //builder.Entity<Question>(entity =>
            //{
            //    entity.HasKey(e => e.Id);
            //    entity.Property(x => x.Id).ValueGeneratedOnAdd();

            //    entity.ToTable("Question");

            //});

            //builder.Entity<Option>(entity =>
            //{
            //    entity.HasKey(e => e.Id);
            //    entity.Property(x => x.Id).ValueGeneratedOnAdd();
            //    entity.ToTable("Option");

            //});
            ////  builder.Entity<Option>().HasOne(a => a.Question).WithOne(b => b.).HasForeignKey<Option>(c => c.Id).OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_Option_Question");
            //builder.Entity<Answers>().HasOne(a => a.Option).WithMany(b => b.Answers).HasForeignKey(c => c.OptionId).OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_Answers_Option");
            //builder.Entity<Answers>().HasOne(a => a.SurveyUser).WithMany(b => b.Answers).HasForeignKey(c => c.UserId).OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_Answers_SurveyUser");
            //builder.Entity<Option>().HasOne(a => a.Question).WithMany(b => b.Options).HasForeignKey(c => c.QuestionId).OnDelete(DeleteBehavior.ClientSetNull).HasConstraintName("FK_Option_Question1");

            base.OnModelCreating(builder);
        }
     
    }
}
