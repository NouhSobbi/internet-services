﻿using System;

namespace Application.Common
{
    public class Class1
    {
    }
}
