﻿using Application.Core.Interfaces;
using Application.Core.Options;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using midTerm.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class OptionsController : ControllerBase
    {

        IConfiguration _config;
        public OptionsController(IConfiguration config)
        {
            _config = config;
        }
        // GET: QuestionController
        [Route("GetAll")]
        public async Task< ActionResult> GetAllOptions()
        {
            return new JsonResult( new { data = await new OptionsCRUD(_config).RetrieveAll() });
        }

        // GET: QuestionController/Details/5
        public ActionResult Get(int id)
        {
            return new JsonResult(new { data = new OptionsCRUD(_config).Retrieve(id) });
        }

        [HttpPost]
        public ActionResult Create(Option o)
        {
            return new JsonResult(new { data = new OptionsCRUD(_config).Insert(o)});
        }


        [HttpPost]
        public ActionResult Update(Option o)
        {
            return new JsonResult(new { data = new OptionsCRUD(_config).Update(o) });
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            return new JsonResult(new { data = new OptionsCRUD(_config).Delete(id) });
        }


        
    }
}
