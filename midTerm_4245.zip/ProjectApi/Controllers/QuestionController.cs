﻿using Application.Core.Interfaces;

using Application.Core.Questions;
using Application.Infraestructure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using midTerm.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class QuestionController : ControllerBase
    {
        IConfiguration _config;
        public QuestionController(IConfiguration config)
        {
            _config = config;
        }
        // GET: QuestionController
        [Route("GetAllQuestions")]
        public async Task<ActionResult> GetAllQuestions()
        {
            return new JsonResult(new { data = await new QuestionsCRUD(_config).RetrieveAll() });
        }

        // GET: QuestionController/Details/5
        public ActionResult Get(int id)
        {
            return new JsonResult(new { data = new QuestionsCRUD(_config).Retrieve(id) });
        }

        [HttpPost]
        public ActionResult Create(Question o)
        {
            return new JsonResult(new { data = new QuestionsCRUD(_config).Insert(o) });
        }


        [HttpPost]
        public ActionResult Update(Question o)
        {
            return new JsonResult(new { data = new QuestionsCRUD(_config).Update(o) });
        }

        [HttpPost]
        public ActionResult Delete(int id)
        {
            return new JsonResult(new { data = new QuestionsCRUD(_config).Delete(id) });
        }



    }
}
